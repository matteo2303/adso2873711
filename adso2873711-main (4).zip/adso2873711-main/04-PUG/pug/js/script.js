let msg = document.querySelector(".msg")
msg.textContent = "welcome: mateo herrera"